﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos
{
    public class ventas
    {
        private int ID_Venta;
        private DateTime fecha;
        private int ID_Cliente;
        private int ID_Empleado;

        public int ID_Venta1 { get => ID_Venta; set => ID_Venta = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }
        public int ID_Cliente1 { get => ID_Cliente; set => ID_Cliente = value; }
        public int ID_Empleado1 { get => ID_Empleado; set => ID_Empleado = value; }

        public static DataTable cargarventas()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Ventas";
            SqlDataAdapter ad = new SqlDataAdapter(comando, con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            return dt;
        }
    }
}
