﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos
{
    public class TiposObras
    {
        private string ID_Tipo_Obra;
        private string nombre;

        public string ID_Tipo_Obra1 { get => ID_Tipo_Obra; set => ID_Tipo_Obra = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public static DataTable cargarTipos_Obras()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Tipos_Obras";
            SqlDataAdapter ad = new SqlDataAdapter(comando, con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            return dt;
        }
    }
}
