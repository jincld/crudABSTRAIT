﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos
{
    public class Obras
    {
        private int ID_Obra;
        private string Nombre;
        private string Descripcion;
        private string Foto;
        private int Cantidad_Disponble;
        private string Precio;
        private int Nombre_Tipo_Obra;

        public int ID_Obra1 { get => ID_Obra; set => ID_Obra = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Descripcion1 { get => Descripcion; set => Descripcion = value; }
        public string Foto1 { get => Foto; set => Foto = value; }
        public int Cantidad_Disponble1 { get => Cantidad_Disponble; set => Cantidad_Disponble = value; }
        public string Precio1 { get => Precio; set => Precio = value; }
        public int Nombre_Tipo_Obra1 { get => Nombre_Tipo_Obra; set => Nombre_Tipo_Obra = value; }

        public static DataTable Cargar()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Obras";
            SqlDataAdapter ad = new SqlDataAdapter(comando, con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            return dt;
            
        }

        public bool InsertarObras(string nombre, string descripcion, int cantidad_disponible, string precio, int nombre_tipo_obra)
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "insert into Obras(Nombre, Descripcion, Cantidad_Disponible, Precio, ID_Tipo_Obra) VALUES(@nombre, @descripcion, @Cantidad_Disponible, @precio, @ID_Tipo_Obra);";
            SqlCommand cmd = new SqlCommand(comando, con);
            cmd.Parameters.AddWithValue("@nombre", nombre);
            cmd.Parameters.AddWithValue("@descripcion", descripcion);
            cmd.Parameters.AddWithValue("@cantidad_disponible",cantidad_disponible);
            cmd.Parameters.AddWithValue("@precio", precio);
            cmd.Parameters.AddWithValue("@nombre_tipo_obra", nombre_tipo_obra);

            if(cmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }


        }
    }
}
