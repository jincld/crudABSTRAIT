﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos
{
    public class Detalle_Ventas
    {
        private int ID_Detalle;
        private int cantidad;
        private double Total;
        private int ID_Venta;
        private int ID_Obra;

        public int ID_Detalle1 { get => ID_Detalle; set => ID_Detalle = value; }
        public int Cantidad { get => cantidad; set => cantidad = value; }
        public double Total1 { get => Total; set => Total = value; }
        public int ID_Venta1 { get => ID_Venta; set => ID_Venta = value; }
        public int ID_Obra1 { get => ID_Obra; set => ID_Obra = value; }

        public static DataTable cargarDetalle_Ventas()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Detalle_Ventas";
            SqlDataAdapter ad = new SqlDataAdapter(comando, con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            return dt;
        }
    }
}
