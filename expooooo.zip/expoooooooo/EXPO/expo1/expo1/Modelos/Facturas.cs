﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos
{
    public class Facturas
    {
        private int ID_Factura;
        private DateTime fecha;
        private double total;
        private int ID_Venta;

        public int ID_Factura1 { get => ID_Factura; set => ID_Factura = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }
        public double Total { get => total; set => total = value; }
        public int ID_Venta1 { get => ID_Venta; set => ID_Venta = value; }

        public static DataTable cargarFacturas()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Facturas";
            SqlDataAdapter ad = new SqlDataAdapter(comando, con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            return dt;
        }
    }
}
