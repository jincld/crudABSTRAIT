﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Modelos
{
    public class Usuario
    {
        private int id;
        private string Nombre_Usuario;
        private string Contrasena;
        private int rol;

        public int Id { get => id; set => id = value; }
        public string Nombre_Usuario1 { get => Nombre_Usuario; set => Nombre_Usuario = value; }
        public string Contrasena1 { get => Contrasena; set => Contrasena = value; }
        public int Rol { get => rol; set => rol = value; }

        public static DataTable cargarusuarios()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Usuarios";
            SqlDataAdapter ad = new SqlDataAdapter(comando, con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            return dt;
        }

        public bool Insertar()
        {
            return false;
        }

        public bool Actualizar()
        {
            return false;
        }

        public bool Eliminar()
        {
            return false;
        }

        public Usuario IniciarSesion()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Usuarios where Nombre_Usuario = @Nombre_Usuario and contrasena = @contrasena";

            SqlCommand cmd = new SqlCommand(comando, con);

            cmd.Parameters.AddWithValue("@Nombre_Usuario", Nombre_Usuario);
            cmd.Parameters.AddWithValue("@contrasena", Contrasena);

            SqlDataReader rd = cmd.ExecuteReader();

            if (rd.Read())
            {
                Usuario u = new Usuario();

                u.id = (int)rd[0];
                u.Nombre_Usuario = (string)rd[1];
                //u.rol = (int)rd[3];

                return u;
            }
            else
            {
                return null;
            }
        }
    }
}


