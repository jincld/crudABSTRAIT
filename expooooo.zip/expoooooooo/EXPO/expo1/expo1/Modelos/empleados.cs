﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos
{
    public class empleados
    {
        private string ID_Empeado;
        private string nombre;
        private string apellido;
        private int edad;
        private string telefono;
        private string DUI;
        private string correo;
        private int ID_Tipo_Empleado;
        private int ID_Usuario;
        private string foto;

        public string ID_Empeado1 { get => ID_Empeado; set => ID_Empeado = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public int Edad { get => edad; set => edad = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public string DUI1 { get => DUI; set => DUI = value; }
        public string Correo { get => correo; set => correo = value; }
        public int ID_Tipo_Empleado1 { get => ID_Tipo_Empleado; set => ID_Tipo_Empleado = value; }
        public int ID_Usuario1 { get => ID_Usuario; set => ID_Usuario = value; }
        public string Foto { get => foto; set => foto = value; }

        public static DataTable cargarEmpleados()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Tipos_Obras";
            SqlDataAdapter ad = new SqlDataAdapter(comando, con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            return dt;
        }
    }
}
