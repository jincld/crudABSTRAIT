﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos
{
    public class Clientes
    {
        private int ID_Cliente;
        private string nombre;
        private string apellido;
        private string direccion;
        private string telefono;
        private int edad;
        private string genero;
        private string foto;

        public int ID_Cliente1 { get => ID_Cliente; set => ID_Cliente = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public int Edad { get => edad; set => edad = value; }
        public string Genero { get => genero; set => genero = value; }
        public string Foto { get => foto; set => foto = value; }

        public static DataTable cargarClientes()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Clientes";
            SqlDataAdapter ad = new SqlDataAdapter(comando, con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            return dt;
        }
    }
}
