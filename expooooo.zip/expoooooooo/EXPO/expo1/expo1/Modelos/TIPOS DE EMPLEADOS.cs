﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos
{
    internal class TIPOS_DE_EMPLEADOS
    {
        private int ID_tipo_empleado;
        private string nombre_tipo;

        public int ID_tipo_empleado1 { get => ID_tipo_empleado; set => ID_tipo_empleado = value; }
        public string Nombre_tipo { get => nombre_tipo; set => nombre_tipo = value; }

        public static DataTable cargartipodeempleados()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Tipos_Empleados";
            SqlDataAdapter ad = new SqlDataAdapter(comando, con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            return dt;
        }
    }
}
 