﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Modelos;

namespace expo1
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnSiguienteI_Click(object sender, EventArgs e)
        {
            Usuario u = new Usuario();
            u.Nombre_Usuario1 = txtUsuarioLogin.Text;
            u.Contrasena1 = txtContraLogin.Text;
            try
            {
                u = u.IniciarSesion();

                if(u == null)
                {
                    MessageBox.Show("Credenciales Inválidas");
                }
                else
                {
                    frmDashboard ds = new frmDashboard(u);

                    Hide();
                    ds.ShowDialog();
                    Show();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Iniciar_Sesión_Load(object sender, EventArgs e)
        {

        }

        private void btnContinuarLogin_Click(object sender, EventArgs e)
        {
            Usuario u = new Usuario();
            u.Nombre_Usuario1 = txtUsuarioLogin.Text;
            u.Contrasena1 = txtContraLogin.Text;

            try
            {
                u = u.IniciarSesion();

                if(u == null)
                {
                    MessageBox.Show("Credenciales Inválidas");
                }
                else
                {
                    frmDashboard ds = new frmDashboard(u);
                    Hide();

                    ds.ShowDialog();

                    Show();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtContraLogin.UseSystemPasswordChar = false;
            }
            else
            {
                txtContraLogin.UseSystemPasswordChar = true;
            }
        }

        private void txtContraLogin_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Abstrait ab = new Abstrait();
            this.Close();
            this.FormClosed += delegate
            {
                ab.Show();
            };
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
