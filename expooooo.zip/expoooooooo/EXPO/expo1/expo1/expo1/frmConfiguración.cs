﻿using Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace expo1
{
    public partial class frmConfiguracion : Form
    {
        Usuario v;
        public frmConfiguracion(Usuario u)
        {
            InitializeComponent();
            v = u;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            frmDashboard das = new frmDashboard(v);
            this.Close();
            this.FormClosed += delegate
            {
                das.Show();
            };
        }

        private void btnEmpleados_Click(object sender, EventArgs e)
        {
            frmUsuarios empleado = new frmUsuarios(v);
            empleado.Show();
            this.Hide();
            empleado.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmDashboard das = new frmDashboard(v);
            this.Close();
            this.FormClosed += delegate
            {
                das.Show();
            };
        }

        private void btnVentas_Click(object sender, EventArgs e)
        {
            frmVentas venta = new frmVentas(v);
            venta.Show();
            this.Hide();
            venta.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEsculturas_Click(object sender, EventArgs e)
        {
            frmObras escultura = new frmObras(v);
            escultura.Show();
            this.Hide();
            escultura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnCompra_Click(object sender, EventArgs e)
        {
            frmClientes comprador = new frmClientes(v);
            comprador.Show();
            this.Hide();
            comprador.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnPinturas_Click(object sender, EventArgs e)
        {
            Pinturas pintura = new Pinturas(v);
            pintura.Show();
            this.Hide();
            pintura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {

        }

        private void btnInicio_Click(object sender, EventArgs e)
        {
            frmDashboard das = new frmDashboard(v);
            this.Close();
            this.FormClosed += delegate
            {
                das.Show();
            };
        }

        private void btnVentas_Click_1(object sender, EventArgs e)
        {
            frmVentas venta = new frmVentas(v);
            venta.Show();
            this.Hide();
            venta.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnPinturas_Click_1(object sender, EventArgs e)
        {
            Pinturas pintura = new Pinturas(v);
            pintura.Show();
            this.Hide();
            pintura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEsculturas_Click_1(object sender, EventArgs e)
        {
            frmObras escultura = new frmObras(v);
            escultura.Show();
            this.Hide();
            escultura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnCompra_Click_1(object sender, EventArgs e)
        {
            frmClientes comprador = new frmClientes(v);
            comprador.Show();
            this.Hide();
            comprador.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEmpleados_Click_1(object sender, EventArgs e)
        {
            frmUsuarios empleado = new frmUsuarios(v);
            empleado.Show();
            this.Hide();
            empleado.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmConfiguracion_Load(object sender, EventArgs e)
        {

        }
    }
}
