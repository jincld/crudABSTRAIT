﻿using Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace expo1
{
    public partial class frmUsuarios : Form
    {
        Usuario v;

        public frmUsuarios( Usuario u)
        {
            InitializeComponent();

            v = u;
            
        }

        private void btnPinturas_Click(object sender, EventArgs e)
        {
            Pinturas pintura = new Pinturas(v);
            pintura.Show();
            this.Hide();
            pintura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEmpleados_Click_1(object sender, EventArgs e)
        {
            
        }

        private void btnCompra_Click_1(object sender, EventArgs e)
        {
            frmClientes comprador = new frmClientes(v);
            comprador.Show();
            this.Hide();
            comprador.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEsculturas_Click_1(object sender, EventArgs e)
        {
            frmObras escultura = new frmObras(v);
            escultura.Show();
            this.Hide();
            escultura.FormClosed += delegate
            {
                this.Show();
            };

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            frmDashboard das = new frmDashboard(v);
            this.Close();
            this.FormClosed += delegate
            {
                das.Show();
            };
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnVentas_Click(object sender, EventArgs e)
        {
            frmVentas venta = new frmVentas(v);
            venta.Show();
            this.Hide();
            venta.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            frmConfiguracion con = new frmConfiguracion(v);
            con.Show();
            this.Hide();
            con.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnVentas_Click_1(object sender, EventArgs e)
        {
            frmVentas venta = new frmVentas(v);
            venta.Show();
            this.Hide();
            venta.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnInicio_Click(object sender, EventArgs e)
        {
            frmDashboard das = new frmDashboard(v);
            this.Close();
            this.FormClosed += delegate
            {
                das.Show();
            };
        }

        private void btnPinturas_Click_1(object sender, EventArgs e)
        {
            Pinturas pintura = new Pinturas(v);
            pintura.Show();
            this.Hide();
            pintura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEsculturas_Click(object sender, EventArgs e)
        {
            frmObras escultura = new frmObras(v);
            escultura.Show();
            this.Hide();
            escultura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnCompra_Click(object sender, EventArgs e)
        {
            frmClientes comprador = new frmClientes(v);
            comprador.Show();
            this.Hide();
            comprador.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEmpleados_Click(object sender, EventArgs e)
        {
            
        }

        private void btnConfig_Click_1(object sender, EventArgs e)
        {
            frmConfiguracion con = new frmConfiguracion(v);
            con.Show();
            this.Hide();
            con.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void dgvUsuarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
