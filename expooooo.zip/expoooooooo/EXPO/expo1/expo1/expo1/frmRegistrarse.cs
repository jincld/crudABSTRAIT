﻿using Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace expo1
{
    public partial class frmRegistrarse : Form
    {
        
        public frmRegistrarse()
        {
            InitializeComponent();

            
        }

        private void btnSuigienteR_Click(object sender, EventArgs e)
        {
            if (txtUsuarioRegistro.Text == "admin" && txtCorreo.Text == "admin@gmail.com" && txtContraRegistro.Text == "admin")
            {
                frmLogin L1 = new frmLogin();
                L1.Show();
                this.Hide();
                L1.FormClosed += delegate
                {
                    this.Show();
                };
            }
            else
            {
                MessageBox.Show("Ingrese su contraseña.", "Error");
                return;

            }
        }

        private void txtUsuarioR_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRegistrarse_Click(object sender, EventArgs e)
        {
            frmLogin iniciar = new frmLogin();
            iniciar.Show();
            this.Hide();
            iniciar.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtContraRegistro.UseSystemPasswordChar = false;
            }
            else
            {
                txtContraRegistro.UseSystemPasswordChar = true;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Abstrait ab = new Abstrait();
            this.Close();
            this.FormClosed += delegate
            {
                ab.Show();
            };
        }
    }
}
