﻿using Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace expo1
{
    public partial class Abstrait : Form
    {
        
        public Abstrait()
        {
            InitializeComponent();

            
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            frmLogin login = new frmLogin();
            login.Show();
            this.Hide();
            login.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnRegistrarse_Click(object sender, EventArgs e)
        {
            frmRegistrarse register = new frmRegistrarse();
            register.Show();
            this.Hide();
            register.FormClosed += delegate
             {
                 this.Show();
             };
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            frmLogin login = new frmLogin();
            login.Show();
            this.Hide();
            login.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            frmRegistrarse register = new frmRegistrarse();
            register.Show();
            this.Hide();
            register.FormClosed += delegate
            {
                this.Show();
            };
        }
    }
}
