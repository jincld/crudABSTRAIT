﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Modelos;

namespace expo1
{
    public partial class frmDashboard : Form
    {
        Usuario v;
        public frmDashboard(Usuario u)
        {
            InitializeComponent();
            lbUsuario.Text = u.Nombre_Usuario1;

            if(u.Rol == 0)
            {
                btnUsuarios.Visible = false;
            }

            v = u;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnPinturas_Click(object sender, EventArgs e)
        {
            Pinturas pintura = new Pinturas(v);
            pintura.Show();
            this.Hide();
            pintura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEsculturas_Click(object sender, EventArgs e)
        {
            frmObras escultura = new frmObras(v);
            escultura.Show();
            this.Hide();
            escultura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnCompra_Click(object sender, EventArgs e)
        {
            frmClientes comprador = new frmClientes(v);
            comprador.Show();
            this.Hide();
            comprador.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEmpleados_Click(object sender, EventArgs e)
        {
            frmUsuarios empleado = new frmUsuarios(v);
            empleado.Show();
            this.Hide();
            empleado.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            frmLogin lo = new frmLogin();
            this.Close();
            this.FormClosed += delegate
            {
                lo.Show();
            };
        }

        private void btnVentas_Click(object sender, EventArgs e)
        {
            frmVentas venta = new frmVentas(v);
            venta.Show();
            this.Hide();
            venta.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            {
                frmConfiguracion con = new frmConfiguracion(v);
                con.Show();
                this.Hide();
                con.FormClosed += delegate
                {
                    this.Show();
                };
            }
        }

        private void btnInicio_Click(object sender, EventArgs e)
        {

        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            frmVentas venta = new frmVentas(v);
            Hide();
            venta.ShowDialog();
            Show();            
        }

        private void btnPinturas_Click_1(object sender, EventArgs e)
        {
            Pinturas pintura = new Pinturas(v);
            pintura.Show();
            this.Hide();
            pintura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnConfig_Click_1(object sender, EventArgs e)
        {
            frmConfiguracion con = new frmConfiguracion(v);
            con.Show();
            this.Hide();
            con.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            frmObras escultura = new frmObras(v);
            escultura.Show();
            this.Hide();
            escultura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnCompra_Click_1(object sender, EventArgs e)
        {
            frmClientes comprador = new frmClientes(v);
            comprador.Show();
            this.Hide();
            comprador.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            frmUsuarios empleado = new frmUsuarios(v);
            empleado.Show();
            this.Hide();
            empleado.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }
    }
}
