USE master
GO

DROP DATABASE IF EXISTS DataBase_Abstrait;
GO

CREATE DATABASE DataBase_Abstrait;
GO

USE DataBase_Abstrait;
GO


CREATE TABLE Tipos_Usuarios(
ID_Tipo_Usuario INT PRIMARY KEY IDENTITY(1,1),
Nombre_Tipo_Usuario VARCHAR(50) NOT NULL
);
GO

CREATE TABLE Clientes(
ID_Cliente INT PRIMARY KEY IDENTITY(1,1),
Nombre VARCHAR(50) NOT NULL,
Apellido VARCHAR(50) NOT NULL,
Direccion VARCHAR(255) NOT NULL,
Telefono VARCHAR(20) NOT NULL,
Edad INT NOT NULL,
Genero VARCHAR(20),
Foto NVARCHAR(max)
);
GO

CREATE TABLE Tipos_Obras(
ID_Tipo_Obra INT PRIMARY KEY IDENTITY(1,1),
Nombre_Tipo_Obra VARCHAR(50) NOT NULL
);
GO

CREATE TABLE Usuarios(
ID_Usuario INT PRIMARY KEY IDENTITY(1,1),
Nombre VARCHAR(50) NOT NULL,
Apellido VARCHAR(50) NOT NULL,
Nombre_Usuario VARCHAR(50) NOT NULL,
Contrasena VARCHAR(MAX),
Edad INT NOT NULL,
Telefono VARCHAR(20) NOT NULL,
DUI INT NOT NULL,
Correo VARCHAR(100) NOT NULL,
Tipo_Usuario VARCHAR(50) NOT NULL,
Foto NVARCHAR(MAX),
);
GO

CREATE TABLE Obras(
ID_Obra INT PRIMARY KEY IDENTITY(1,1),
Nombre VARCHAR(50) NOT NULL,
Descripcion VARCHAR(350) NOT NULL,
Foto varchar(200),
Cantidad_Disponible INT NOT NULL,
Precio Decimal(10,2) NOT NULL,
ID_Tipo_Obra INT,
Nombre_Tipo_Obra VARCHAR(50)NOT NULL,

CONSTRAINT FK_Tipos_Obras
FOREIGN KEY(ID_Tipo_Obra)
REFERENCES Tipos_Obras(ID_Tipo_Obra)
ON DELETE CASCADE
ON UPDATE CASCADE
);
GO

CREATE TABLE Ventas(
ID_Venta INT PRIMARY KEY IDENTITY(1,1),
Fecha DATE NOT NULL,
ID_Cliente INT NOT NULL,
ID_Usuario INT NOT NULL,
Cantidad INT NOT NULL,
Total DECIMAL(10,2),
ID_Obra1 INT NOT NULL,
ID_Obra2 INT NOT NULL,
ID_Obra3 INT NOT NULL,
ID_Obra4 INT NOT NULL,

CONSTRAINT FK_Clientes
FOREIGN KEY (ID_Cliente)
REFERENCES Clientes(ID_Cliente)
ON DELETE CASCADE
ON UPDATE CASCADE,

CONSTRAINT FK_Usuarios
FOREIGN KEY (ID_Usuario)
REFERENCES Usuarios(ID_Usuario)
ON DELETE CASCADE
ON UPDATE CASCADE,

CONSTRAINT FK_Obras
FOREIGN KEY (ID_Obra1)
REFERENCES Obras(ID_Obra)
ON DELETE CASCADE
ON UPDATE CASCADE
);
GO

CREATE TABLE Facturas(
ID_Factura INT PRIMARY KEY IDENTITY(1,1),
Fecha DATE NOT NULL,
Total DECIMAL(10,2) NOT NULL,
ID_Venta INT NOT NULL,

FOREIGN KEY (ID_Venta)
REFERENCES Ventas(ID_Venta)
ON DELETE CASCADE
ON UPDATE CASCADE,
);
GO

	

INSERT INTO Usuarios(Nombre, Apellido, Nombre_Usuario, Contrasena, Edad, Telefono, DUI, Correo, Tipo_Usuario)
VALUES('admin', 'uno', 'admin', 'admin1', 20, '2233-9900', 1234567, 'admin@gmail.com', 'Administrador'),
      ('empleado', 'uno', 'empleado', 'empleado1', 20, '2233-9900', 1234567, 'empleado@gmail.com', 'Empleado');

INSERT INTO Tipos_Usuarios(Nombre_Tipo_Usuario)
VALUES('Administrador'),
      ('Empleado');

INSERT INTO Clientes(Nombre, Apellido, Direccion, Telefono,Edad, Genero)
VALUES('luis','perez','calle el sunsal #45','7890-9090', 45, 'hombre'),
      ('carla','lois','colonia vistas de santa ana #67','7723-8989', 50, 'mujer'),
	  ('malcolm','smith','santa elena #7','7534-8911', 23, 'hombre'),
	  ('charles','stone','santa tecla #4','7333-8080', 30, 'hombre'),
	  ('abigail','arias','soyapango city #88','7788-0099', 80, 'mujer'),
	  ('rose','kim','seul corea del sur #78','7555-5577', 29, 'mujer'),
	  ('danielle','marsh','australia','7655-5454', 19, 'mujer'),
	  ('minji','kim','corea del sur','7900-0087', 19, 'mujer'),
	  ('tomas','walkman','estados unidos','7899-0088', 34, 'hombre'),
	  ('jiwoo','park','isla jeju','7445-4432', 24, 'hombre');

INSERT INTO Tipos_Obras(Nombre_Tipo_Obra)
VALUES('Pintura'),
      ('Escultura');
	
insert into Obras(Nombre, Descripcion, Cantidad_Disponible, Precio, Nombre_Tipo_Obra)
VALUES('La noche estrellada', 'Es un paisaje nocturno que representa una versi�n idealizada de la localidad de Saint-R�my-de-Provence, Francia, bajo un cielo estrellado.', 1, 500.50, 'Escultura');
insert into Obras(Nombre, Descripcion, Cantidad_Disponible, Precio, Nombre_Tipo_Obra)
VALUES('Los Girasoles', 'Los girasoles es una serie de cuadros al �leo realizados por el pintor neerland�s Vincent van Gogh. De la serie hay tres cuadros similares', 1, 250.55, 'Pintura');
GO

SELECT * FROM Usuarios;
  

