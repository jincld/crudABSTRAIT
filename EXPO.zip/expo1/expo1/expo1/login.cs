﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace expo1
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void btnSiguienteI_Click(object sender, EventArgs e)
        {
            if (txtContraLogin.Text == "admin" && txtUsuarioLogin.Text == "admin")
            {
                Dashboard m1 = new Dashboard();
                m1.Show();
                this.Hide();
                m1.FormClosed += delegate
                 {
                     this.Show();
                 };
            }
            else
            {
                MessageBox.Show("Ingrese su contraseña.", "Error");
                return;

            }
        }

        private void Iniciar_Sesión_Load(object sender, EventArgs e)
        {

        }

        private void btnContinuarLogin_Click(object sender, EventArgs e)
        {
            if (txtUsuarioLogin.Text == "admin" && txtContraLogin.Text == "admin")
            {
                Dashboard menu1 = new Dashboard();
                menu1.Show();
                this.Hide();
                menu1.FormClosed += delegate
                {
                    this.Show();
                };
            }

            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtContraLogin.UseSystemPasswordChar = false;
            }
            else
            {
                txtContraLogin.UseSystemPasswordChar = true;
            }
        }

        private void txtContraLogin_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Abstrait ab = new Abstrait();
            this.Close();
            this.FormClosed += delegate
            {
                ab.Show();
            };
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
