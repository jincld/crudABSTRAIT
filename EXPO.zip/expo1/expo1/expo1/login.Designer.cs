﻿namespace expo1
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(login));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUsuarioLogin = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtContraLogin = new System.Windows.Forms.TextBox();
            this.btnolvidar = new System.Windows.Forms.Button();
            this.btnSiguienteI = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnContinuarLogin = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(93)))), ((int)(((byte)(81)))));
            this.label1.Font = new System.Drawing.Font("Arial", 48F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(133, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(451, 75);
            this.label1.TabIndex = 2;
            this.label1.Text = "Iniciar Sesión";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(93)))), ((int)(((byte)(81)))));
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 24F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(107, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 40);
            this.label3.TabIndex = 4;
            this.label3.Text = "Usuario";
            // 
            // txtUsuarioLogin
            // 
            this.txtUsuarioLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.txtUsuarioLogin.Location = new System.Drawing.Point(114, 289);
            this.txtUsuarioLogin.Name = "txtUsuarioLogin";
            this.txtUsuarioLogin.Size = new System.Drawing.Size(470, 44);
            this.txtUsuarioLogin.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(93)))), ((int)(((byte)(81)))));
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 24F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(107, 339);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(199, 40);
            this.label2.TabIndex = 6;
            this.label2.Text = "Contraseña";
            // 
            // txtContraLogin
            // 
            this.txtContraLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.txtContraLogin.Location = new System.Drawing.Point(114, 382);
            this.txtContraLogin.Name = "txtContraLogin";
            this.txtContraLogin.Size = new System.Drawing.Size(470, 44);
            this.txtContraLogin.TabIndex = 7;
            this.txtContraLogin.UseSystemPasswordChar = true;
            this.txtContraLogin.TextChanged += new System.EventHandler(this.txtContraLogin_TextChanged);
            // 
            // btnolvidar
            // 
            this.btnolvidar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(93)))), ((int)(((byte)(81)))));
            this.btnolvidar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnolvidar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnolvidar.ForeColor = System.Drawing.Color.White;
            this.btnolvidar.Location = new System.Drawing.Point(134, 750);
            this.btnolvidar.Name = "btnolvidar";
            this.btnolvidar.Size = new System.Drawing.Size(336, 50);
            this.btnolvidar.TabIndex = 11;
            this.btnolvidar.Text = "¿Olvido su contraseña?";
            this.btnolvidar.UseVisualStyleBackColor = false;
            // 
            // btnSiguienteI
            // 
            this.btnSiguienteI.BackColor = System.Drawing.Color.Black;
            this.btnSiguienteI.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSiguienteI.ForeColor = System.Drawing.Color.White;
            this.btnSiguienteI.Location = new System.Drawing.Point(689, 960);
            this.btnSiguienteI.Name = "btnSiguienteI";
            this.btnSiguienteI.Size = new System.Drawing.Size(233, 59);
            this.btnSiguienteI.TabIndex = 12;
            this.btnSiguienteI.Text = "Siguiente";
            this.btnSiguienteI.UseVisualStyleBackColor = false;
            this.btnSiguienteI.Click += new System.EventHandler(this.btnSiguienteI_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(93)))), ((int)(((byte)(81)))));
            this.checkBox1.Font = new System.Drawing.Font("MS Reference Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox1.Location = new System.Drawing.Point(114, 435);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(267, 33);
            this.checkBox1.TabIndex = 13;
            this.checkBox1.Text = "Mostrar Contraseña";
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(93)))), ((int)(((byte)(81)))));
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(109, 495);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(290, 29);
            this.label4.TabIndex = 14;
            this.label4.Text = "¿Olvidó su contraseña?";
            // 
            // btnContinuarLogin
            // 
            this.btnContinuarLogin.BackColor = System.Drawing.Color.Black;
            this.btnContinuarLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContinuarLogin.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContinuarLogin.ForeColor = System.Drawing.Color.White;
            this.btnContinuarLogin.Location = new System.Drawing.Point(308, 641);
            this.btnContinuarLogin.Name = "btnContinuarLogin";
            this.btnContinuarLogin.Size = new System.Drawing.Size(383, 92);
            this.btnContinuarLogin.TabIndex = 15;
            this.btnContinuarLogin.Text = "Continuar";
            this.btnContinuarLogin.UseVisualStyleBackColor = false;
            this.btnContinuarLogin.Click += new System.EventHandler(this.btnContinuarLogin_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(93)))), ((int)(((byte)(81)))));
            this.pictureBox2.Image = global::expo1.Properties.Resources._582073_2001;
            this.pictureBox2.Location = new System.Drawing.Point(27, 25);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 48);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::expo1.Properties.Resources._2;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1434, 745);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1434, 745);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnContinuarLogin);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.btnSiguienteI);
            this.Controls.Add(this.btnolvidar);
            this.Controls.Add(this.txtContraLogin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtUsuarioLogin);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Iniciar Sesión";
            this.Load += new System.EventHandler(this.Iniciar_Sesión_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUsuarioLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtContraLogin;
        private System.Windows.Forms.Button btnolvidar;
        private System.Windows.Forms.Button btnSiguienteI;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnContinuarLogin;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}