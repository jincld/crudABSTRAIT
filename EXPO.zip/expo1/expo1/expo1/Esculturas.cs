﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace expo1
{
    public partial class Esculturas : Form
    {
        public Esculturas()
        {
            InitializeComponent();
        }

        private void btnPinturas_Click(object sender, EventArgs e)
        {
            Pinturas pintura = new Pinturas();
            pintura.Show();
            this.Hide();
            pintura.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEsculturas_Click(object sender, EventArgs e)
        {
            
        }

        private void btnCompra_Click(object sender, EventArgs e)
        {
            Compradores comprador = new Compradores();
            comprador.Show();
            this.Hide();
            comprador.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEmpleados_Click(object sender, EventArgs e)
        {
            Empleados empleado = new Empleados();
            empleado.Show();
            this.Hide();
            empleado.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Dashboard das = new Dashboard();
            this.Close();
            this.FormClosed += delegate
            {
                das.Show();
            };
        }

        private void btnVentas_Click(object sender, EventArgs e)
        {
            Ventas venta = new Ventas();
            venta.Show();
            this.Hide();
            venta.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Configuración con = new Configuración();
            con.Show();
            this.Hide();
            con.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnInicio_Click(object sender, EventArgs e)
        {
            Dashboard das = new Dashboard();
            this.Close();
            this.FormClosed += delegate
            {
                das.Show();
            };
        }

        private void btnVentas_Click_1(object sender, EventArgs e)
        {
            Ventas venta = new Ventas();
            venta.Show();
            this.Hide();
            venta.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            Dashboard das = new Dashboard();
            this.Close();
            this.FormClosed += delegate
            {
                das.Show();
            };
        }

        private void btnEsculturas_Click_1(object sender, EventArgs e)
        {
            
        }

        private void btnCompra_Click_1(object sender, EventArgs e)
        {
            Compradores comprador = new Compradores();
            comprador.Show();
            this.Hide();
            comprador.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnEmpleados_Click_1(object sender, EventArgs e)
        {
            Empleados empleado = new Empleados();
            empleado.Show();
            this.Hide();
            empleado.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            Configuración con = new Configuración();
            con.Show();
            this.Hide();
            con.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {

        }
    }
}
