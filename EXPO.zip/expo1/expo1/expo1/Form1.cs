﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace expo1
{
    public partial class Abstrait : Form
    {
        public Abstrait()
        {
            InitializeComponent();
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide();
            login.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnRegistrarse_Click(object sender, EventArgs e)
        {
            Registrarse register = new Registrarse();
            register.Show();
            this.Hide();
            register.FormClosed += delegate
             {
                 this.Show();
             };
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide();
            login.FormClosed += delegate
            {
                this.Show();
            };
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            Registrarse register = new Registrarse();
            register.Show();
            this.Hide();
            register.FormClosed += delegate
            {
                this.Show();
            };
        }
    }
}
