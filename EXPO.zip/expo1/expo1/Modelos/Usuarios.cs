﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Modelos
{
    public class Usuarios
    {
        private int iD_Usuario;
        private string nombre_Usuario;
        private string contrasena;

        public int ID_Usuario { get => iD_Usuario; set => iD_Usuario = value; }
        public string Nombre_Usuario { get => nombre_Usuario; set => nombre_Usuario = value; }
        public string Contrasena { get => contrasena; set => contrasena = value; }

        public static DataTable cargarusuarios()
        {
            SqlConnection con = Conexion.Conectar();
            string comando = "select * from Usuarios";
            SqlDataAdapter ad = new SqlDataAdapter(comando, con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            return dt;
        }
    }
}
